import 'package:flutter/material.dart';

class AppColors {
  static const Color PRIMARY = Color.fromRGBO(161, 43, 43, 1);
  static const Color GREY = Color.fromRGBO(244, 244, 244, 1);
  static const Color BLUE = Color.fromRGBO(16, 16, 125, 1);
}
